// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <iostream>

// Custom exception class
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom Exception Occurred";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl; // This function demonstrates more complex application logic.
    throw std::runtime_error("An error occurred in even more custom application logic."); // Throws a standard exception to simulate an error condition.

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;
    // This function combines the call to do_even_more_custom_application_logic()
    // with an exception handler that catches std::exception, displays
    // a message and the exception.what(), then continues processing.
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cout << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }


    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    std::cout << "Leaving Custom Application Logic." << std::endl;
    throw CustomException();
    // Throws a custom exception derived from std::exception
    // This will be caught explicitly in main.

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0)
    {
        // This function performs division and throws an exception to handle
        // divide by zero errors using a standard C++ defined exception.
        throw std::overflow_error("Division by zero error.");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    float numerator = 10.0f;
    float denominator = 0;
    // This function creates an exception handler to capture ONLY the exception
    // thrown by divide.
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::overflow_error& e)
    {
        std::cout << "Exception caught in do_division: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // The main function creates exception handlers that catch (in this order):
    // + CustomException
    // + std::exception
    // + any uncaught exceptions
    // and displays a message to the console.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) // + CustomException
    {
        std::cerr << "CustomException Caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) // + std::exception
    {
        std::cerr << "std::exception caught in main: " << e.what() << std::endl;
    }
    catch (...) // + any uncaught exceptions
    {
        std::cerr << "Unknown exception caught in main" << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu